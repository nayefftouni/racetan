const puppeteer = require('puppeteer');
const { google } = require('googleapis');
const fs = require('fs');

// Load JSON key dynamically
const keyPath = '/home/nayefftouni/racetan/puppeteer-scraper/rapid-domain-445419-k1-afb12b954979.json'; // Replace with your JSON key file path
let keys;
try {
  keys = JSON.parse(fs.readFileSync(keyPath, 'utf8'));
} catch (error) {
  console.error('Error reading JSON key file:', error.message);
  process.exit(1);
}

async function scrapeAndSendToSheet() {
  const url = 'https://sadadpay.net/pay/898652662642702';

  // 1. Initialize Puppeteer
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: 'networkidle2' });

  try {
    // 2. Wait for the target element and scrape its content
    await page.waitForSelector('span.text-150.text-success-d3.opacity-2', { timeout: 5000 });

    const scrapedText = await page.evaluate(() => {
      const element = document.querySelector('span.text-150.text-success-d3.opacity-2');
      return element ? element.textContent.trim() : null;
    });

    if (scrapedText) {
      console.log('Scraped Data:', scrapedText);

      // 3. Send data to Google Sheets
      await sendToGoogleSheet(scrapedText);
    } else {
      console.log('Target element not found.');
    }
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await browser.close();
  }
}

async function sendToGoogleSheet(scrapedData) {
  // Authenticate using the Service Account
  const auth = new google.auth.GoogleAuth({
    credentials: keys,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });

  const sheets = google.sheets({ version: 'v4', auth });

  // Google Sheet ID and target range
  const spreadsheetId = '13-st8B7uL-nh_HePmMa6sJbuxkLY0eheEowisVBqQvw'; // Replace with your Sheet ID
  const range = 'Links Withrawal!E31'; // Adjust to your target cell or range

  // Append the data to the Google Sheet
  try {
    const response = await sheets.spreadsheets.values.append({
      spreadsheetId,
      range,
      valueInputOption: 'USER_ENTERED',
      resource: {
        values: [[scrapedData]],
      },
    });
    console.log('Data successfully added to Google Sheet:', response.data);
  } catch (error) {
    console.error('Error while sending to Google Sheets:', error.message);
  }
}

scrapeAndSendToSheet();